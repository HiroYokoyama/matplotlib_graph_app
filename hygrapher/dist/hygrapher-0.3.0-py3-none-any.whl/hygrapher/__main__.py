# hygrapher/__main__.py
import sys
from .main import main

if __name__ == "__main__":
    # main() を呼び出し、適切な終了コードで終了する
    sys.exit(main())
    