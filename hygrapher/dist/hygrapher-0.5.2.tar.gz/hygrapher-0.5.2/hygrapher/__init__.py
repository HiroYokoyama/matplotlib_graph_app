# hygrapher/__init__.py
from .main import GraphApp, main
